<?php defined( 'ABSPATH' ) or exit; ?>

<ul>
	<li><a href="https://getshortcodes.com/docs-category/addons/" target="_blank"><?php _e( 'Full add-ons documentation', 'shortcodes-ultimate' ); ?></a></li>
</ul>
